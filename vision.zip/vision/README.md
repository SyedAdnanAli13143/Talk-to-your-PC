# Talk-to-your-PC

A fully-local voice agent for Windows. Speak to your PC, get natural-sounding replies, control apps. Multilingual: English, Roman English (Karachi-style Urdu in Latin letters), and Urdu script.

**Private by default** — no API keys, no cloud calls, no telemetry. Everything runs on your laptop.

---

## What it does

- 🎙 **Hears you** — offline speech-to-text via [faster-whisper](https://github.com/SYSTRAN/faster-whisper)
- 🧠 **Thinks** — local LLM via [Ollama](https://ollama.com/) (default: `qwen2.5:7b`)
- 🗣 **Talks back** — neural TTS via [Piper](https://github.com/rhasspy/piper), lips sync to actual phonemes + audio amplitude
- 🎯 **Takes action** — opens apps, runs web searches, creates folders / files (via LLM tool calls)
- 🎭 **Has personality** — 5 swappable moods (friendly / professional / sassy / calm / playful), each with its own voice prosody and avatar expression
- 🌐 **Multilingual** — strict language matching: English in → English out; Roman English in → Roman English out

---

## Architecture

```
       you speak                   you type / read
          │                              │
          ▼                              ▼
   ┌──────────────────────────────────────────┐
   │            pywebview window              │
   │  (HTML + CSS + JS · animated avatar)     │
   └────────────┬───────────────┬─────────────┘
                │ audio (webm)   │ text
                ▼                ▼
   ┌──────────────────────────────────────────┐
   │            Python  ui/app.py             │
   └─┬──────────────┬──────────────┬──────────┘
     │              │              │
     ▼              ▼              ▼
 faster-whisper   Ollama        Piper TTS
   small/CPU    qwen2.5:7b    en_US-amy-medium
   (STT)        (LLM + tools)  (neural TTS + alignments)
```

Nothing leaves your machine at runtime. Models are downloaded once on first setup, then cached locally.

---

## Quick start

### Prerequisites
- Windows 10 / 11
- Python 3.10+ — <https://www.python.org/downloads/> (tick "Add Python to PATH" on install)
- [Ollama](https://ollama.com/download) — runs as a Windows service after install

### Install

Clone or copy the project, then double-click:

```
setup.bat
```

This will:
- Install Python packages from `requirements.txt`
- Copy `.env.example` → `.env`
- Verify Ollama is running
- Pull the LLM model (`qwen2.5:7b`, ~4.7 GB on first run)
- Pre-download Whisper-small (~150 MB) and Piper voice (~30 MB)

Total one-time download: **~5 GB**. Re-running `setup.bat` is safe — already-installed steps are skipped.

### Run

Double-click:

```
run.bat
```

Or:

```
python ui/app.py
```

---

## Configuration

Edit `.env` to swap models or tune behaviour:

```
OLLAMA_HOST=http://localhost:11434
OLLAMA_MODEL=qwen2.5:7b          # try qwen2.5:3b for snappier voice latency
OLLAMA_NUM_PREDICT=600

WHISPER_DEVICE=cpu               # or cuda if you have CUDA 12 toolkit
WHISPER_COMPUTE=int8
```

After editing, click the Ollama pill in the app to re-check status.

---

## Project layout

```
Talk-to-your-PC/
├── setup.bat            ← one-click installer (Windows)
├── setup.py             ← cross-platform setup logic
├── run.bat              ← one-click launcher
├── requirements.txt     ← pinned Python deps
├── .env.example         ← config template
├── core/
│   ├── llm_client.py    ← Ollama wrapper + tool-call loop
│   ├── whisper_stt.py   ← faster-whisper integration (CPU/CUDA)
│   ├── piper_tts.py     ← Piper TTS with per-sentence prosody
│   ├── system_prompt.py ← Vision personality + language rules
│   └── tools.py         ← open/create handlers + JSON schemas
└── ui/
    ├── app.py           ← pywebview launcher + Python ↔ JS bridge
    └── web/
        ├── index.html
        ├── styles.css
        └── app.js       ← STT, TTS, lip-sync, mood, action rendering
```

---

## Tools (current)

The agent can call these via Ollama tool use:

| Tool | What it does |
|---|---|
| `open_app(name)` | Launch a specific Windows application by name |
| `open_url(url, browser?)` | Open a URL, optionally in a specific browser |
| `web_search(query, browser?, engine?)` | Run a web search (Google / Bing / DDG / YouTube) |
| `create_folder(path)` | Create a folder (with parent dirs) |
| `create_file(path, content?)` | Create a NEW text file (refuses to overwrite) |
| `open_in_app(file_path, app)` | Open a specific file with a specific app |

No delete, no read, no overwrite in this phase — by design.

---

## Privacy

What stays local:
- Microphone audio
- Whisper transcripts
- LLM context and replies
- Conversation history (in-memory only, capped at 16 turns)

What touches the network:
- One-time downloads on first install (Hugging Face for Whisper + Piper voices, Ollama registry for the LLM model). After that, runtime is fully offline.

No API keys are required or stored anywhere.

---

## Roadmap

- **Phase 1 (now)**: voice loop, multilingual, open + create actions
- **Phase 2**: WhatsApp send / read, calendar, reminders, take_screenshot
- **Phase 3**: read files (with consent), delete with confirmation gate, run_powershell with confirm
- **Future**: Android companion app, wake-word ("Hey Vision"), speaker authentication

---

## Tech stack

Python 3.10+, [pywebview](https://pywebview.flowrl.com/) (Edge WebView2), [Ollama](https://ollama.com/), [faster-whisper](https://github.com/SYSTRAN/faster-whisper), [Piper TTS](https://github.com/rhasspy/piper), [Qwen 2.5](https://qwenlm.github.io/blog/qwen2.5/).
