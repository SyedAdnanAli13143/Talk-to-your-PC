// Vision UI — front-end. Voice in (Web Speech API) + voice out (Web Speech API)
// + LLM via the Python ↔ pywebview bridge.
//
// Architecture:
//   - STT: window.SpeechRecognition (browser-native; works online via Edge's
//     speech service). Whisper-offline will replace this in a later iteration.
//   - LLM: pywebview.api.chat(text)  →  routes to Ollama on localhost:11434.
//   - TTS: window.speechSynthesis (uses installed Windows voices, fully local).
//
// State machine:  idle → listening → thinking → speaking → idle

(() => {
  'use strict';

  // ── DOM ──────────────────────────────────────────────────
  const body          = document.body;
  const chatEl        = document.getElementById('chat');
  const textInput     = document.getElementById('textInput');
  const sendBtn       = document.getElementById('sendBtn');
  const micBtn        = document.getElementById('micBtn');
  const moodPicker    = document.getElementById('moodPicker');
  const stateLabel    = document.getElementById('stateLabel');
  const stateHint     = document.getElementById('stateHint');
  const clearBtn      = document.getElementById('clearBtn');
  const langPill      = document.getElementById('langPill');
  const langFlag      = document.getElementById('langFlag');
  const langLabel     = document.getElementById('langLabel');
  const ollamaPill    = document.getElementById('ollamaPill');
  const ollamaLabel   = document.getElementById('ollamaLabel');
  const eyeLeft       = document.querySelector('.eye-left');
  const eyeRight      = document.querySelector('.eye-right');

  const setupOverlay  = document.getElementById('setupOverlay');
  const setupCmd      = document.getElementById('setupCmd');
  const setupSub      = document.getElementById('setupSub');
  const setupStatus   = document.getElementById('setupStatus');
  const setupRetry    = document.getElementById('setupRetry');
  const setupDismiss  = document.getElementById('setupDismiss');

  // ── state ────────────────────────────────────────────────
  /** @type {'idle'|'listening'|'thinking'|'speaking'} */
  let state    = 'idle';
  let mood     = 'friendly';
  let lang     = 'en-US';            // STT language hint; toggled by langPill

  // Whisper recording state
  let mediaRecorder = null;
  let audioStream   = null;
  let audioCtx      = null;
  let audioAnalyser = null;
  let audioRafId    = null;
  let audioChunks   = [];
  let recordingStartedAt = 0;
  let whisperWarmedUp = false;       // first transcription loads the model

  const STATE_COPY = {
    idle:      'say something',
    listening: 'listening...',
    thinking:  'thinking...',
    speaking:  'speaking',
  };

  const LANGS = {
    'en-US': { flag: 'EN', label: 'english' },
    'ur-PK': { flag: 'UR', label: 'urdu' },
  };

  // mood-driven TTS settings. Rates kept close to 1.0 — going too fast/slow
  // degrades intelligibility on Windows voices. Pitch carries most of the
  // personality.  perChar is the FALLBACK typing speed only used if the
  // engine doesn't fire onboundary events.
  const MOOD_VOICE = {
    friendly:     { rate: 0.98, pitch: 1.05, perChar: 55 },
    professional: { rate: 1.00, pitch: 0.95, perChar: 52 },
    sassy:        { rate: 1.08, pitch: 1.12, perChar: 46 },
    calm:         { rate: 0.88, pitch: 0.95, perChar: 65 },
    playful:      { rate: 1.10, pitch: 1.15, perChar: 44 },
  };

  function setState(next) {
    state = next;
    body.dataset.state = next;
    stateLabel.textContent = STATE_COPY[next];
    if (next === 'idle')      setRestViseme();
    if (next === 'thinking')  setViseme('mm');
    if (next === 'listening') setRestViseme();
  }

  function setMood(next) {
    mood = next;
    body.dataset.mood = next;
    moodPicker.querySelectorAll('.mood-btn').forEach(b => {
      b.classList.toggle('active', b.dataset.mood === next);
    });
    if (state === 'idle') setRestViseme();
    safeApi('set_mood', next);
  }

  function setLang(next) {
    if (!LANGS[next]) return;
    lang = next;
    body.dataset.lang = next;
    langFlag.textContent = LANGS[next].flag;
    langLabel.textContent = LANGS[next].label;
  }

  // ── pywebview bridge ─────────────────────────────────────
  function pyReady() {
    return !!(window.pywebview && window.pywebview.api);
  }
  async function safeApi(method, ...args) {
    if (!pyReady()) return null;
    try {
      const fn = window.pywebview.api[method];
      if (typeof fn !== 'function') return null;
      return await fn(...args);
    } catch (err) {
      console.warn('api error', method, err);
      return null;
    }
  }
  function waitForBridge(maxMs = 6000) {
    return new Promise(resolve => {
      if (pyReady()) return resolve(true);
      const start = Date.now();
      const tick = () => {
        if (pyReady()) return resolve(true);
        if (Date.now() - start > maxMs) return resolve(false);
        setTimeout(tick, 80);
      };
      tick();
    });
  }

  // ── ollama status ────────────────────────────────────────
  async function refreshStatus() {
    body.dataset.llm = 'checking';
    ollamaLabel.textContent = 'checking...';
    const status = await safeApi('get_status');
    applyStatus(status);
    return status;
  }
  function applyStatus(status) {
    if (!status || !status.llm) {
      body.dataset.llm = 'error';
      ollamaLabel.textContent = 'no bridge';
      return;
    }
    const llm = status.llm;
    if (llm.ok) {
      body.dataset.llm = 'ready';
      ollamaLabel.textContent = `ollama · ${llm.model}`;
      hideSetup();
    } else if (llm.ollama_running && !llm.model_pulled) {
      body.dataset.llm = 'needs-setup';
      ollamaLabel.textContent = `model: ${llm.model.split(':')[0]} not pulled`;
      showSetup(llm.hint || `Run:  ollama pull ${llm.model}`, llm.model);
    } else {
      body.dataset.llm = 'needs-setup';
      ollamaLabel.textContent = 'ollama not running';
      showSetup(llm.hint || 'Ollama service nahi mil raha.', llm.model);
    }
  }

  function showSetup(hint, model) {
    if (model && setupCmd) setupCmd.textContent = `ollama pull ${model}`;
    if (setupSub) setupSub.textContent = hint;
    setupOverlay.hidden = false;
    setupStatus.textContent = '';
    setupStatus.className = 'setup-status';
  }
  function hideSetup() {
    setupOverlay.hidden = true;
  }

  // ── chat rendering ───────────────────────────────────────
  function addMsg(role, text) {
    const wrap = document.createElement('div');
    wrap.className = `msg ${role}`;
    wrap.innerHTML =
      `<div class="msg-avatar"></div>
       <div class="msg-bubble"></div>`;
    wrap.querySelector('.msg-bubble').textContent = text;
    chatEl.appendChild(wrap);
    chatEl.scrollTop = chatEl.scrollHeight;
    return wrap;
  }
  function renderAction(action) {
    const ok = action && action.result && action.result.ok;
    const tool = action.tool || 'unknown';
    let text = '';
    if (ok) {
      text = action.result.message || `${tool} done`;
    } else {
      const err = (action.result && action.result.error) || 'failed';
      text = `${tool} failed — ${err}`;
    }
    const wrap = document.createElement('div');
    wrap.className = 'msg-action' + (ok ? '' : ' err');
    wrap.innerHTML =
      `<span class="msg-action-icon">${ok ? '⚙' : '⚠'}</span>
       <span class="msg-action-text"></span>`;
    wrap.querySelector('.msg-action-text').textContent = text;
    chatEl.appendChild(wrap);
    chatEl.scrollTop = chatEl.scrollHeight;
  }

  function addTyping() {
    const wrap = document.createElement('div');
    wrap.className = 'msg agent typing-msg';
    wrap.innerHTML =
      `<div class="msg-avatar"></div>
       <div class="msg-bubble"><div class="typing"><span></span><span></span><span></span></div></div>`;
    chatEl.appendChild(wrap);
    chatEl.scrollTop = chatEl.scrollHeight;
    return wrap;
  }

  // ── conversation loop ────────────────────────────────────
  async function handleUserText(text) {
    if (!text || !text.trim()) return;
    const clean = text.trim();
    addMsg('user', clean);
    textInput.value = '';

    setState('thinking');
    const typing = addTyping();

    const apiResp = await safeApi('chat', clean, lang);
    typing.remove();

    if (!apiResp) {
      setState('idle');
      addMsg('agent', 'bridge ready nahi hai. window restart karo.');
      return;
    }
    if (!apiResp.ok) {
      setState('idle');
      const reply = apiResp.text || 'kuch ghalat ho gaya. ollama check karo.';
      const bubble = addMsg('agent', '');
      await typeOut(bubble.querySelector('.msg-bubble'), reply, MOOD_VOICE[mood].perChar);
      // re-check status — likely needs-setup
      refreshStatus();
      return;
    }

    // Render any tool actions the model executed before the final reply
    const actions = (apiResp && apiResp.actions) || [];
    actions.forEach(renderAction);

    const reply = (apiResp.text || '').trim();
    if (reply) {
      setState('speaking');
      const bubble = addMsg('agent', '');
      // single coordinated call — TTS speaks AND typing reveals + visemes drive
      // from the same audio playback so they stay in sync
      await speakAndType(bubble.querySelector('.msg-bubble'), reply);
    }

    setState('idle');
  }

  // crude language guess for picking the TTS voice; English-leaning since
  // most replies will be Roman English (Urdu in Latin letters) or English
  function guessOutputLang(text) {
    if (/[؀-ۿ]/.test(text)) return 'ur-PK';   // any Urdu/Arabic codepoint
    return 'en-US';
  }

  // ── STT: Whisper via MediaRecorder + pywebview bridge ───
  // The browser captures mic audio (webm/opus), we base64-encode it, send
  // to Python, and faster-whisper transcribes locally on the GPU.

  function arrayBufferToBase64(buffer) {
    const bytes = new Uint8Array(buffer);
    let binary = '';
    const chunk = 0x8000;
    for (let i = 0; i < bytes.length; i += chunk) {
      binary += String.fromCharCode.apply(null, bytes.subarray(i, i + chunk));
    }
    return btoa(binary);
  }

  function pickMimeType() {
    const candidates = [
      'audio/webm;codecs=opus',
      'audio/webm',
      'audio/ogg;codecs=opus',
      'audio/mp4',
      '',
    ];
    if (typeof MediaRecorder === 'undefined') return null;
    for (const t of candidates) {
      if (!t) return '';  // browser default
      if (MediaRecorder.isTypeSupported(t)) return t;
    }
    return null;
  }

  async function startRecording() {
    if (typeof MediaRecorder === 'undefined') {
      stateHint.textContent = 'mic recording not supported';
      return false;
    }

    // 1) get mic
    try {
      audioStream = await navigator.mediaDevices.getUserMedia({
        audio: {
          echoCancellation: true,
          noiseSuppression: true,
          autoGainControl: true,
        },
      });
    } catch (e) {
      const name = (e && e.name) || '';
      if (name === 'NotAllowedError' || name === 'SecurityError') {
        stateHint.textContent = 'mic permission denied';
      } else if (name === 'NotFoundError') {
        stateHint.textContent = 'no mic found';
      } else {
        stateHint.textContent = `mic error: ${name || 'unknown'}`;
      }
      return false;
    }

    // 2) audio level meter (drives --mic-level CSS variable)
    try {
      const Ctx = window.AudioContext || window.webkitAudioContext;
      audioCtx = new Ctx();
      const source = audioCtx.createMediaStreamSource(audioStream);
      audioAnalyser = audioCtx.createAnalyser();
      audioAnalyser.fftSize = 256;
      audioAnalyser.smoothingTimeConstant = 0.7;
      source.connect(audioAnalyser);
      drawLevel();
    } catch {}

    // 3) MediaRecorder
    const mime = pickMimeType();
    if (mime === null) {
      stopAudioStream();
      stateHint.textContent = 'recorder not supported';
      return false;
    }
    audioChunks = [];
    try {
      mediaRecorder = mime
        ? new MediaRecorder(audioStream, { mimeType: mime })
        : new MediaRecorder(audioStream);
    } catch (e) {
      stopAudioStream();
      stateHint.textContent = 'recorder init failed';
      return false;
    }
    mediaRecorder.ondataavailable = (e) => {
      if (e.data && e.data.size > 0) audioChunks.push(e.data);
    };
    mediaRecorder.onstop = onRecordingDone;
    mediaRecorder.onerror = (e) => {
      console.warn('mediaRecorder error', e);
    };
    recordingStartedAt = Date.now();
    mediaRecorder.start();
    stateHint.textContent = 'sun rahi hoon, dobara tap to send';
    return true;
  }

  function stopRecording() {
    if (mediaRecorder && mediaRecorder.state !== 'inactive') {
      try { mediaRecorder.stop(); } catch {}
    }
  }

  function stopAudioStream() {
    if (audioRafId) {
      cancelAnimationFrame(audioRafId);
      audioRafId = null;
    }
    document.documentElement.style.setProperty('--mic-level', '0');
    if (audioStream) {
      audioStream.getTracks().forEach(t => t.stop());
      audioStream = null;
    }
    if (audioCtx) {
      try { audioCtx.close(); } catch {}
      audioCtx = null;
    }
    audioAnalyser = null;
  }

  function drawLevel() {
    if (!audioAnalyser) return;
    const data = new Uint8Array(audioAnalyser.frequencyBinCount);
    audioAnalyser.getByteFrequencyData(data);
    let sum = 0;
    for (let i = 0; i < data.length; i++) sum += data[i];
    const avg = sum / data.length;
    // map ~0..80 → 0..1 with a small floor so the ring always pulses a bit
    const level = Math.min(1, Math.max(0.05, avg / 80));
    document.documentElement.style.setProperty('--mic-level', level.toFixed(3));
    audioRafId = requestAnimationFrame(drawLevel);
  }

  async function onRecordingDone() {
    const elapsed = Date.now() - recordingStartedAt;
    stopAudioStream();

    if (audioChunks.length === 0 || elapsed < 350) {
      stateHint.textContent = 'too short — tap and speak';
      setState('idle');
      return;
    }

    // hand off to Whisper
    setState('thinking');
    stateHint.textContent = whisperWarmedUp
      ? 'transcribing...'
      : 'warming up whisper (first time only)...';

    const blob = new Blob(audioChunks, {
      type: mediaRecorder.mimeType || 'audio/webm',
    });
    const buffer = await blob.arrayBuffer();
    const b64 = arrayBufferToBase64(buffer);

    const result = await safeApi('transcribe', b64, lang);

    if (!result || !result.ok) {
      const reason = result && result.reason;
      const errTxt = result && (result.error || result.text);
      let msg = 'transcribe failed';
      if (reason === 'load_failed') msg = 'whisper load failed: ' + (errTxt || '');
      else if (errTxt) msg = errTxt;
      stateHint.textContent = msg;
      setState('idle');
      return;
    }

    whisperWarmedUp = true;
    const text = (result.text || '').trim();
    if (!text) {
      stateHint.textContent = 'koi awaaz samjh nahi aayi';
      setState('idle');
      return;
    }

    stateHint.textContent = 'tap the mic, or type below';
    handleUserText(text);
  }

  async function toggleMic() {
    if (state === 'thinking') {
      // ignore mic clicks while transcribing/thinking
      return;
    }
    if (state === 'speaking') {
      // tap to interrupt the current reply
      cancelSpeech();
      setState('idle');
      return;
    }

    if (state === 'listening') {
      // second tap → finalize and transcribe
      stopRecording();
      return;
    }

    // idle → start a new recording
    setState('listening');
    const ok = await startRecording();
    if (!ok) setState('idle');
  }

  // ── TTS (Web Speech Synthesis) ───────────────────────────
  let cachedVoices = [];
  function refreshVoices() {
    cachedVoices = window.speechSynthesis ? speechSynthesis.getVoices() : [];
  }
  if (window.speechSynthesis) {
    refreshVoices();
    speechSynthesis.onvoiceschanged = refreshVoices;
  }

  // Voice ranking — neural/online voices sound dramatically better than
  // the legacy Desktop voices (David/Mark/Hazel are robotic). We prefer:
  //   1. Anything with "Neural", "Online", or "Natural" in the name
  //   2. Known-good named voices: Aria, Jenny, Guy, Heera, Asad
  //   3. Non-Desktop voices in the right language
  //   4. Anything in the right language
  //   5. Whatever's available
  function pickVoice(langPref) {
    if (!cachedVoices.length) refreshVoices();
    if (!cachedVoices.length) return null;
    const prefix = (langPref || 'en-US').split('-')[0].toLowerCase();
    const inLang = cachedVoices.filter(v => v.lang.toLowerCase().startsWith(prefix));
    const pool   = inLang.length ? inLang : cachedVoices;

    const tier1 = pool.find(v => /neural|online|natural/i.test(v.name));
    if (tier1) return tier1;

    const tier2 = pool.find(v => /\b(aria|jenny|guy|heera|asad|libby|sonia|ryan)\b/i.test(v.name));
    if (tier2) return tier2;

    const tier3 = inLang.find(v => !/desktop/i.test(v.name));
    if (tier3) return tier3;

    return inLang[0] || pool[0];
  }

  // Strip anything that TTS would mispronounce or read literally.
  // The model is instructed not to emit these, but we strip defensively so
  // a slip doesn't ruin the audio.
  function cleanForSpeech(text) {
    return text
      .replace(/\.{3,}/g, ',')                 // ... → ,
      .replace(/…/g, ',')                      // ellipsis char → ,
      .replace(/\s+\/\s+/g, ' or ')            // " / " → " or "
      .replace(/(\d)\/(\d)/g, '$1 of $2')      // "5/10" → "5 of 10"
      .replace(/[*_`#]/g, '')                  // markdown leftovers
      .replace(/—/g, ', ')                     // em-dash → comma
      .replace(/–/g, ', ')                     // en-dash → comma
      .replace(/&/g, ' and ')                  // ampersand
      .replace(/\s+([,.!?])/g, '$1')           // remove space before punctuation
      .replace(/[,.!?]{2,}/g, m => m[0])       // collapse repeated punctuation
      .replace(/\s{2,}/g, ' ')                 // collapse spaces
      .trim();
  }

  // Map a phoneme (espeak/IPA-style, returned by Piper) to one of our 6
  // viseme shapes. This is rough but tracks the broad mouth-open / mouth-
  // round / lip-closed buckets that read well visually.
  function phonemeToViseme(p) {
    if (!p) return 'rest';
    const c = p.toLowerCase().trim();
    if (!c || c === '_' || c === '#') return 'rest';
    // bilabial closure
    if (/^[mbp]/.test(c)) return 'mm';
    // rounded vowels & glide
    if (/^[owu]/.test(c) || /[ɔʊɒuː]/.test(c)) return 'oo';
    // open vowels
    if (/^[a]/.test(c) || /[ɑæɐ]/.test(c)) return 'aa';
    // front/mid vowels
    if (/^[eiy]/.test(c) || /[ɛɪɨə]/.test(c)) return 'eh';
    // nasals (slight open)
    if (/^[nŋ]/.test(c)) return 'mm';
    // sibilants/fricatives — small open
    return 'eh';
  }

  // Track currently playing audio so we can cancel on interruption.
  let currentAudio    = null;
  let currentAudioRaf = null;
  let currentAudioCtx = null;

  // Speak the reply via Piper (fully-local neural TTS) AND reveal the chat
  // bubble in time with the audio playback. Visemes are driven by Piper's
  // phoneme alignments — each phoneme has a precise start/end timestamp,
  // so the mouth shape changes match the actual sound being produced.
  // Falls back to speechSynthesis if Piper isn't loaded yet.
  function speakAndType(node, originalText) {
    const cleaned = cleanForSpeech(originalText);
    node.textContent = '';
    return playPiper(node, cleaned).catch(err => {
      console.warn('piper failed, falling back', err);
      return speechSynthesisFallback(node, cleaned);
    });
  }

  async function playPiper(node, cleaned) {
    const result = await safeApi('synth', cleaned, mood);
    if (!result || !result.ok || !result.audio_b64) {
      throw new Error((result && result.reason) || 'no-audio');
    }

    const alignments = result.alignments || [];
    const audio = new Audio('data:audio/wav;base64,' + result.audio_b64);
    audio.preload = 'auto';
    currentAudio = audio;

    // Web Audio amplitude analyser drives the continuous face/lip motion.
    // Phoneme alignments only set the mouth SHAPE; amplitude sets the
    // OPENING. Combined, this produces smooth, natural lip motion that
    // tracks the actual voice instead of jittering on rapid phoneme changes.
    let analyser = null;
    let timeBuf = null;
    try {
      const Ctx = window.AudioContext || window.webkitAudioContext;
      const ctx = new Ctx();
      currentAudioCtx = ctx;
      const src = ctx.createMediaElementSource(audio);
      analyser = ctx.createAnalyser();
      analyser.fftSize = 512;
      analyser.smoothingTimeConstant = 0.4;
      timeBuf = new Uint8Array(analyser.fftSize);
      src.connect(analyser);
      src.connect(ctx.destination);
    } catch {}

    return new Promise((resolve) => {
      let alignIdx = 0;
      let lastViseme = '';
      let lastVisemeAt = 0;
      const VISEME_MIN_DWELL_MS = 90;   // longer dwell smooths phoneme jitter
      let smoothAmp = 0;
      let lastAmpPushed = 0;
      const root = document.documentElement;

      function tick() {
        const t = audio.currentTime;
        const now = performance.now();

        // text reveal — synced to actual playback time
        if (audio.duration > 0 && isFinite(audio.duration)) {
          const progress = Math.min(1, t / audio.duration);
          const target = Math.floor(cleaned.length * progress);
          if (node.textContent.length < target) {
            node.textContent = cleaned.slice(0, target);
            chatEl.scrollTop = chatEl.scrollHeight;
          }
        }

        // ── audio amplitude (always run — drives face expression) ─────
        let rawAmp = 0;
        if (analyser && timeBuf) {
          analyser.getByteTimeDomainData(timeBuf);
          let sum = 0;
          for (let i = 0; i < timeBuf.length; i++) {
            const v = (timeBuf[i] - 128) / 128;
            sum += v * v;
          }
          rawAmp = Math.min(1, Math.sqrt(sum / timeBuf.length) * 4);
        }
        // Asymmetric smoothing: track peaks moderately fast, decay slowly so
        // the face doesn't twitch on every tiny waveform bump. Net effect is
        // a syllable-envelope follower, not a per-frame waveform follower.
        const ATTACK  = 0.18;   // ~80ms to reach a new peak
        const RELEASE = 0.05;   // ~330ms to relax — keeps mouth open through syllable
        const a = (rawAmp > smoothAmp) ? ATTACK : RELEASE;
        smoothAmp = smoothAmp + (rawAmp - smoothAmp) * a;

        // Only push to CSS when the value moves meaningfully — avoids
        // constant recalculation and visible micro-jitter.
        const next = +smoothAmp.toFixed(2);
        if (Math.abs(next - lastAmpPushed) >= 0.02) {
          root.style.setProperty('--speak-amp', next.toString());
          lastAmpPushed = next;
        }

        // ── viseme SHAPE: phoneme-driven, with min-dwell smoothing ─────
        let nextViseme = null;
        if (alignments.length) {
          while (alignIdx < alignments.length - 1 && alignments[alignIdx + 1].t0 <= t) {
            alignIdx++;
          }
          const cur = alignments[alignIdx];
          if (cur) {
            // when amplitude is near-silence, snap to rest regardless of phoneme
            nextViseme = smoothAmp < 0.07 ? 'rest' : phonemeToViseme(cur.p);
          }
        } else {
          // pure amplitude-driven fallback
          if      (smoothAmp < 0.08) nextViseme = 'rest';
          else if (smoothAmp < 0.25) nextViseme = 'mm';
          else if (smoothAmp < 0.50) nextViseme = 'eh';
          else if (smoothAmp < 0.70) nextViseme = 'oo';
          else                       nextViseme = 'aa';
        }

        if (nextViseme && nextViseme !== lastViseme && (now - lastVisemeAt) > VISEME_MIN_DWELL_MS) {
          setViseme(nextViseme);
          lastViseme = nextViseme;
          lastVisemeAt = now;
        }

        currentAudioRaf = requestAnimationFrame(tick);
      }

      function cleanup() {
        if (currentAudioRaf) cancelAnimationFrame(currentAudioRaf);
        currentAudioRaf = null;
        if (currentAudioCtx) {
          try { currentAudioCtx.close(); } catch {}
          currentAudioCtx = null;
        }
        currentAudio = null;
        node.textContent = cleaned;
        chatEl.scrollTop = chatEl.scrollHeight;
        root.style.setProperty('--speak-amp', '0');
        setRestViseme();
      }

      audio.onended = () => { cleanup(); resolve(); };
      audio.onerror = () => { cleanup(); resolve(); };

      audio.play()
        .then(() => { tick(); })
        .catch(err => { cleanup(); resolve(Promise.reject(err)); });
    });
  }

  // Last-resort fallback to the browser's speechSynthesis (the old path).
  function speechSynthesisFallback(node, cleaned) {
    return new Promise((resolve) => {
      if (!window.speechSynthesis) {
        typeOut(node, cleaned, MOOD_VOICE[mood].perChar).then(resolve);
        return;
      }
      try { speechSynthesis.cancel(); } catch {}
      const utt = new SpeechSynthesisUtterance(cleaned);
      const voice = pickVoice(guessOutputLang(cleaned));
      if (voice) utt.voice = voice;
      const cfg = MOOD_VOICE[mood] || MOOD_VOICE.friendly;
      utt.rate = cfg.rate;
      utt.pitch = cfg.pitch;
      utt.onend = () => { node.textContent = cleaned; setRestViseme(); resolve(); };
      utt.onerror = () => { node.textContent = cleaned; setRestViseme(); resolve(); };
      try { speechSynthesis.speak(utt); }
      catch { typeOut(node, cleaned, cfg.perChar).then(resolve); return; }
      // type in parallel as approximate visual sync
      typeOut(node, cleaned, cfg.perChar);
    });
  }

  function cancelSpeech() {
    try { speechSynthesis.cancel(); } catch {}
    if (currentAudio) {
      try { currentAudio.pause(); currentAudio.currentTime = 0; } catch {}
    }
    if (currentAudioRaf) {
      cancelAnimationFrame(currentAudioRaf);
      currentAudioRaf = null;
    }
    if (currentAudioCtx) {
      try { currentAudioCtx.close(); } catch {}
      currentAudioCtx = null;
    }
    currentAudio = null;
  }

  // ── lip-sync visemes (driven by typed character) ─────────
  const VISEMES = {
    a:'aa', A:'aa',
    e:'eh', E:'eh', i:'eh', I:'eh', y:'eh', Y:'eh',
    o:'oo', O:'oo', u:'oo', U:'oo', w:'oo', W:'oo',
    m:'mm', M:'mm', b:'mm', B:'mm', p:'mm', P:'mm',
    ' ':'rest', '.':'rest', ',':'rest', '!':'rest', '?':'rest',
    '\n':'rest', '\t':'rest', ':':'rest', ';':'rest', '"':'rest',
  };
  function visemeForChar(ch) {
    if (VISEMES[ch] !== undefined) return VISEMES[ch];
    if (/[a-zA-Z؀-ۿ]/.test(ch)) {
      return Math.random() < 0.55 ? 'eh' : 'aa';
    }
    return 'rest';
  }
  function setViseme(name) {
    document.querySelectorAll('.viseme').forEach(v => v.classList.remove('active'));
    const target = document.querySelector('.viseme-' + name);
    if (target) target.classList.add('active');
  }
  const REST_BY_MOOD = {
    friendly: 'rest',
    professional: 'rest',
    sassy: 'rest',
    calm: 'rest',
    playful: 'smile',
  };
  function setRestViseme() {
    setViseme(REST_BY_MOOD[mood] || 'rest');
  }

  // ── helpers ──────────────────────────────────────────────
  const sleep = ms => new Promise(r => setTimeout(r, ms));

  async function typeOut(node, text, perChar = 45, append = false) {
    if (!append) node.textContent = '';
    for (const ch of text) {
      node.textContent += ch;
      chatEl.scrollTop = chatEl.scrollHeight;
      setViseme(visemeForChar(ch));
      // small jitter so it doesn't feel mechanical
      await sleep(perChar + Math.random() * 12 - 4);
    }
    setRestViseme();
  }

  // random eye blinking
  function scheduleBlink() {
    const next = 2200 + Math.random() * 3500;
    setTimeout(() => {
      const eyes = [eyeLeft, eyeRight];
      eyes.forEach(e => e.classList.add('blink'));
      const doubleBlink = Math.random() < 0.18;
      setTimeout(() => {
        eyes.forEach(e => e.classList.remove('blink'));
        if (doubleBlink) {
          setTimeout(() => {
            eyes.forEach(e => e.classList.add('blink'));
            setTimeout(() => eyes.forEach(e => e.classList.remove('blink')), 110);
          }, 140);
        }
      }, 130);
      scheduleBlink();
    }, next);
  }
  scheduleBlink();

  // gentle eye-follow on mouse
  document.addEventListener('mousemove', e => {
    const cx = window.innerWidth / 2;
    const cy = window.innerHeight / 2;
    const dx = (e.clientX - cx) / cx;
    const dy = (e.clientY - cy) / cy;
    const max = 4;
    document.querySelectorAll('.eye-iris').forEach(el => {
      el.style.transform = `translate(${dx * max}px, ${dy * max}px)`;
    });
  });

  // ── wiring ───────────────────────────────────────────────
  sendBtn.addEventListener('click', () => handleUserText(textInput.value));
  textInput.addEventListener('keydown', e => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      handleUserText(textInput.value);
    }
  });

  micBtn.addEventListener('click', toggleMic);

  moodPicker.addEventListener('click', e => {
    const btn = e.target.closest('.mood-btn');
    if (btn) setMood(btn.dataset.mood);
  });

  langPill.addEventListener('click', () => {
    setLang(lang === 'en-US' ? 'ur-PK' : 'en-US');
  });

  ollamaPill.addEventListener('click', refreshStatus);

  clearBtn.addEventListener('click', async () => {
    chatEl.innerHTML = '';
    addMsg('agent', 'naya start. kya karna hai?');
    await safeApi('clear_history');
  });

  setupRetry.addEventListener('click', async () => {
    setupRetry.classList.add('checking');
    setupRetry.textContent = 'checking...';
    setupStatus.textContent = '';
    setupStatus.className = 'setup-status';
    const status = await safeApi('reload_config');
    setupRetry.classList.remove('checking');
    setupRetry.textContent = 're-check ollama';
    if (status && status.llm && status.llm.ok) {
      setupStatus.textContent = 'connected ✓';
      setupStatus.className = 'setup-status ok';
      setTimeout(() => applyStatus(status), 700);
    } else {
      const hint = status && status.llm && status.llm.hint;
      setupStatus.textContent = hint || 'still not reachable';
      setupStatus.className = 'setup-status error';
      if (status) applyStatus(status);
    }
  });
  setupDismiss.addEventListener('click', hideSetup);

  // copy buttons inside setup overlay
  document.querySelectorAll('.setup-copy').forEach(btn => {
    btn.addEventListener('click', () => {
      const target = document.getElementById(btn.dataset.copy);
      if (!target) return;
      const text = target.textContent.trim();
      navigator.clipboard.writeText(text).then(() => {
        btn.classList.add('copied');
        btn.textContent = 'copied ✓';
        setTimeout(() => {
          btn.classList.remove('copied');
          btn.textContent = 'copy';
        }, 1400);
      });
    });
  });

  // ── boot ─────────────────────────────────────────────────
  setLang('en-US');
  setRestViseme();

  (async () => {
    const ok = await waitForBridge();
    if (!ok) {
      body.dataset.llm = 'error';
      ollamaLabel.textContent = 'no bridge';
      stateHint.textContent = 'pywebview bridge not ready';
      return;
    }
    refreshStatus();
  })();

})();
