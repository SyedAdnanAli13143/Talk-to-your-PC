"""Vision launcher — pywebview window + Python ↔ JS bridge.

The bridge exposes a small async-style API to the front-end:
  * get_status()   — Ollama health + UI defaults
  * set_mood()     — switch the active personality
  * chat()         — run one LLM turn (called when user submits text or finishes voice)
  * clear_history()
  * reload_config()— re-read .env after the user pastes / edits it
"""

from __future__ import annotations

import os
import sys
from datetime import datetime
from pathlib import Path

import webview
from dotenv import load_dotenv

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT))

# load .env before importing the LLM client (it reads OLLAMA_* env vars at import time)
load_dotenv(ROOT / ".env")

from core import tools as tool_handlers  # noqa: E402
from core.llm_client import LLMClient  # noqa: E402
from core.piper_tts import PiperTTS  # noqa: E402
from core.system_prompt import AVAILABLE_MOODS, build_system_prompt  # noqa: E402
from core.whisper_stt import WhisperSTT  # noqa: E402

HERE = Path(__file__).resolve().parent
INDEX = HERE / "web" / "index.html"

# Cap conversation history to the most-recent N turns to keep prompts small
# and the model fast. Voice agents don't need long memory in-session.
MAX_HISTORY_TURNS = 16  # 8 user + 8 assistant


class API:
    def __init__(self) -> None:
        self.llm = LLMClient()
        self.stt = WhisperSTT()
        self.tts = PiperTTS()
        self.history: list[dict] = []
        self.mood = "friendly"

    # ── status & config ────────────────────────────────────────────
    def get_status(self) -> dict:
        return {
            "llm": self.llm.status(),
            "stt": self.stt.status(),
            "tts": self.tts.status(),
            "mood": self.mood,
            "moods": list(AVAILABLE_MOODS),
            "history_length": len(self.history),
        }

    # ── voice → text (Whisper, fully local) ───────────────────────
    def transcribe(self, audio_b64: str, lang: str = "") -> dict:
        return self.stt.transcribe(audio_b64, lang or None)

    # ── text → voice (Piper, fully local, phoneme-aligned) ────────
    def synth(self, text: str, mood: str = "") -> dict:
        return self.tts.synthesize(text, mood or self.mood)

    def set_mood(self, mood: str) -> dict:
        if mood in AVAILABLE_MOODS:
            self.mood = mood
            return {"ok": True, "mood": mood}
        return {"ok": False, "reason": "invalid_mood"}

    def clear_history(self) -> dict:
        self.history = []
        return {"ok": True}

    def reload_config(self) -> dict:
        """User edited .env or installed the model — refresh and re-check status."""
        load_dotenv(ROOT / ".env", override=True)
        # re-instantiate so new OLLAMA_* env vars take effect
        self.llm = LLMClient()
        return self.get_status()

    # ── conversation ───────────────────────────────────────────────
    def chat(self, user_text: str, lang_pin: str = "auto") -> dict:
        if not user_text or not user_text.strip():
            return {"ok": False, "reason": "empty", "text": ""}
        user_text = user_text.strip()

        # accept "en-US" / "ur-PK" from the front-end and normalize
        pin = (lang_pin or "auto").lower()
        if pin.startswith("en"):
            pin = "en"
        elif pin.startswith("ur") or pin.startswith("hi") or pin.startswith("ar"):
            pin = "ur"
        elif pin not in ("auto", "en", "ur"):
            pin = "auto"

        # Inject actual current date/time so the LLM never guesses from its
        # training cutoff. Without this, qwen confidently claims it's 2023.
        now = datetime.now()
        runtime_ctx = (
            "# RUNTIME CONTEXT (real, live values — trust these over training data)\n"
            f"Today's date: {now.strftime('%A, %B %d, %Y')} ({now.strftime('%Y-%m-%d')})\n"
            f"Current time: {now.strftime('%I:%M %p').lstrip('0')}\n"
            f"User's location: Karachi, Pakistan (timezone PKT, UTC+5)\n"
            f"User's home folder: {Path.home()}\n"
            f"User's Desktop: {Path.home() / 'Desktop'}\n"
            "When the user asks 'what day is it', 'today', 'tomorrow', etc., use these "
            "values, not training data."
        )
        system = build_system_prompt(self.mood, lang_pin=pin) + "\n\n" + runtime_ctx

        result = self.llm.reply(
            system,
            self.history,
            user_text,
            tools=tool_handlers.SCHEMAS,
            tool_executor=tool_handlers.execute,
        )

        if result.get("ok"):
            self.history.append({"role": "user", "content": user_text})
            self.history.append({"role": "assistant", "content": result["text"]})
            if len(self.history) > MAX_HISTORY_TURNS:
                self.history = self.history[-MAX_HISTORY_TURNS:]
        return result


def main() -> None:
    api = API()
    webview.create_window(
        title="Vision",
        url=str(INDEX),
        js_api=api,
        width=1200,
        height=820,
        min_size=(960, 700),
        background_color="#07070f",
        text_select=True,
        easy_drag=False,
    )
    webview.start(debug=False)


if __name__ == "__main__":
    main()
