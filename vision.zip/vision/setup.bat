@echo off
setlocal
cd /d "%~dp0"

echo.
echo ============================================================
echo   Vision setup
echo ============================================================
echo.

where python >nul 2>&1
if errorlevel 1 (
    echo [X] Python is not installed or not in PATH.
    echo.
    echo Install Python 3.10 or newer from:
    echo     https://www.python.org/downloads/
    echo During install, tick "Add Python to PATH".
    echo.
    pause
    exit /b 1
)

python setup.py %*
set ERR=%errorlevel%
echo.
if not "%ERR%"=="0" (
    echo Setup ran into a problem ^(exit %ERR%^).
    pause
    exit /b %ERR%
)
pause
