"""One-shot setup for Vision.

Run via:
    python setup.py        (any OS)
    setup.bat              (Windows double-click wrapper)

Steps the script performs:
  1. Verify Python version (3.10+).
  2. Install Python packages from requirements.txt.
  3. Copy .env.example → .env if .env is missing.
  4. Check Ollama is reachable on localhost:11434; print install URL if not.
  5. Pull the LLM model declared in .env (default qwen2.5:7b).
  6. Pre-download the Whisper STT model (~150 MB).
  7. Pre-download the Piper TTS voice (~30 MB).
  8. Print disk usage and next steps.

Re-running is safe — every step is idempotent (already-installed packages,
already-pulled models, etc. are skipped).
"""

from __future__ import annotations

import json
import os
import shutil
import subprocess
import sys
import urllib.request
from pathlib import Path

# Force UTF-8 output so Windows cp1252 terminals don't blow up on glyphs.
try:
    sys.stdout.reconfigure(encoding="utf-8", errors="replace")  # type: ignore[attr-defined]
    sys.stderr.reconfigure(encoding="utf-8", errors="replace")  # type: ignore[attr-defined]
except Exception:
    pass


ROOT = Path(__file__).resolve().parent
REQ_FILE = ROOT / "requirements.txt"
ENV_EXAMPLE = ROOT / ".env.example"
ENV_FILE = ROOT / ".env"

# fall back used if .env can't be read yet
DEFAULT_MODEL = "qwen2.5:7b"
DEFAULT_OLLAMA_HOST = "http://localhost:11434"

DOWNLOAD_TOTAL_MB_ESTIMATE = 4_700 + 150 + 30  # qwen 7b Q4 + whisper-small + piper amy


# ── pretty output helpers ─────────────────────────────────────────
GREEN  = "\033[92m"
YELLOW = "\033[93m"
RED    = "\033[91m"
CYAN   = "\033[96m"
DIM    = "\033[2m"
RESET  = "\033[0m"


def banner(text: str) -> None:
    bar = "=" * (len(text) + 4)
    print(f"\n{CYAN}{bar}\n  {text}\n{bar}{RESET}")


def step(msg: str) -> None:
    print(f"\n{CYAN}>{RESET} {msg}")


def ok(msg: str) -> None:
    print(f"  {GREEN}[ok]{RESET}  {msg}")


def warn(msg: str) -> None:
    print(f"  {YELLOW}[!]{RESET}   {msg}")


def fail(msg: str) -> None:
    print(f"  {RED}[X]{RESET}   {msg}")


# ── individual steps ──────────────────────────────────────────────

def check_python() -> bool:
    step("Checking Python version")
    v = sys.version_info
    if v < (3, 10):
        fail(f"Python 3.10+ required, you have {v.major}.{v.minor}.{v.micro}")
        print(f"\n  Install from: {CYAN}https://www.python.org/downloads/{RESET}")
        return False
    ok(f"Python {v.major}.{v.minor}.{v.micro}")
    return True


def install_packages() -> bool:
    step("Installing Python packages (pip install -r requirements.txt)")
    if not REQ_FILE.exists():
        fail(f"missing {REQ_FILE.name}")
        return False
    cmd = [sys.executable, "-m", "pip", "install", "-r", str(REQ_FILE)]
    try:
        subprocess.run(cmd, check=True)
    except subprocess.CalledProcessError as e:
        fail(f"pip install returned {e.returncode}")
        return False
    ok("packages installed")
    return True


def ensure_env() -> bool:
    step("Ensuring .env exists")
    if ENV_FILE.exists():
        ok(f"{ENV_FILE.name} already present")
        return True
    if ENV_EXAMPLE.exists():
        shutil.copy(ENV_EXAMPLE, ENV_FILE)
        ok(f"created {ENV_FILE.name} from {ENV_EXAMPLE.name}")
        return True
    warn("no .env or .env.example — using defaults")
    return False


def read_env_var(key: str, default: str) -> str:
    """Tiny .env reader (we don't import dotenv yet — pip may have just installed it)."""
    if ENV_FILE.exists():
        try:
            for line in ENV_FILE.read_text(encoding="utf-8").splitlines():
                line = line.strip()
                if not line or line.startswith("#") or "=" not in line:
                    continue
                k, _, v = line.partition("=")
                if k.strip() == key:
                    return v.strip().strip('"').strip("'")
        except Exception:
            pass
    return default


def check_ollama() -> bool:
    step("Checking Ollama service")
    host = read_env_var("OLLAMA_HOST", DEFAULT_OLLAMA_HOST)
    try:
        req = urllib.request.Request(f"{host}/api/tags")
        with urllib.request.urlopen(req, timeout=3) as r:
            data = json.loads(r.read().decode("utf-8"))
        models = [m.get("name", "?") for m in data.get("models", [])]
        ok(f"Ollama is running at {host}")
        if models:
            print(f"    {DIM}installed models:{RESET} {', '.join(models)}")
        else:
            print(f"    {DIM}no models pulled yet{RESET}")
        return True
    except Exception as e:
        fail(f"Ollama not reachable ({type(e).__name__})")
        print(f"\n  {YELLOW}Install Ollama:{RESET}  https://ollama.com/download")
        print(f"  {DIM}After install, Ollama starts automatically as a service.{RESET}")
        print(f"  {DIM}Re-run this setup once Ollama is installed.{RESET}\n")
        return False


def pull_model() -> bool:
    model = read_env_var("OLLAMA_MODEL", DEFAULT_MODEL)
    step(f"Pulling Ollama model: {model}")
    print(f"    {DIM}This is the LLM. ~4.7 GB download for qwen2.5:7b on first run.{RESET}")
    if shutil.which("ollama") is None:
        fail("ollama CLI not found in PATH (Ollama may still be installing)")
        return False
    try:
        subprocess.run(["ollama", "pull", model], check=True)
    except subprocess.CalledProcessError as e:
        fail(f"ollama pull failed (exit {e.returncode})")
        return False
    ok(f"{model} ready")
    return True


def prewarm_whisper() -> bool:
    step("Pre-downloading Whisper STT (~150 MB, one time)")
    try:
        from faster_whisper import WhisperModel  # noqa: WPS433
    except ImportError:
        fail("faster-whisper not installed (did pip step succeed?)")
        return False
    try:
        size = os.environ.get("WHISPER_MODEL", "small")
        device = os.environ.get("WHISPER_DEVICE", "cpu")
        compute = os.environ.get("WHISPER_COMPUTE", "int8")
        print(f"    loading whisper '{size}' on {device}/{compute}...")
        WhisperModel(size, device=device, compute_type=compute)
    except Exception as e:
        warn(f"whisper preload failed: {e}")
        print(f"    {DIM}(it'll retry on first transcription, which may be slow){RESET}")
        return False
    ok("whisper ready")
    return True


def prewarm_piper() -> bool:
    step("Pre-downloading Piper TTS voice (~30 MB, one time)")
    try:
        from huggingface_hub import hf_hub_download  # noqa: WPS433
    except ImportError:
        fail("huggingface_hub not installed (did pip step succeed?)")
        return False
    voice = os.environ.get("VISION_VOICE", "en_US-amy-medium")
    base = f"en/en_US/{voice.split('-')[1]}/{voice.split('-')[2]}/{voice}"
    try:
        hf_hub_download(repo_id="rhasspy/piper-voices", filename=f"{base}.onnx")
        hf_hub_download(repo_id="rhasspy/piper-voices", filename=f"{base}.onnx.json")
    except Exception as e:
        warn(f"piper voice preload failed: {e}")
        return False
    ok(f"piper voice '{voice}' cached")
    return True


def report_disk() -> None:
    step("Disk space")
    try:
        usage = shutil.disk_usage(str(ROOT))
        gb_free = usage.free / (1024 ** 3)
        gb_total = usage.total / (1024 ** 3)
        line = f"{gb_free:.1f} GB free of {gb_total:.0f} GB on {ROOT.drive}"
        if gb_free < 6:
            warn(line + " — tight; Vision needs ~5 GB")
        else:
            ok(line)
    except Exception as e:
        warn(str(e))


def print_next_steps(ollama_up: bool) -> None:
    banner("Setup complete")
    if not ollama_up:
        print(f"\n{YELLOW}1. Install Ollama:{RESET}  https://ollama.com/download")
        print(f"{YELLOW}2. Re-run setup:{RESET}   python setup.py")
        print(f"{YELLOW}   (or){RESET}            setup.bat\n")
        return
    if os.name == "nt":
        run_hint = "run.bat              (or)  python ui\\app.py"
    else:
        run_hint = "python ui/app.py"
    print(f"\n{GREEN}Launch Vision:{RESET}  {run_hint}")
    print(f"{DIM}   First launch is slowest — qwen, whisper, and piper are loaded into memory.{RESET}")
    print(f"\n{DIM}   .env is at {ENV_FILE} — edit OLLAMA_MODEL there to swap models.{RESET}\n")


# ── main ──────────────────────────────────────────────────────────

def main() -> int:
    # enable ANSI colors on Windows terminals
    if os.name == "nt":
        os.system("")

    banner("Vision setup")
    print(f"{DIM}Project: {ROOT}{RESET}")
    print(f"{DIM}Estimated downloads on a fresh machine: ~{DOWNLOAD_TOTAL_MB_ESTIMATE} MB{RESET}")

    if not check_python():
        return 1
    if not install_packages():
        return 1

    ensure_env()
    ollama_up = check_ollama()

    if ollama_up:
        pull_model()

    prewarm_whisper()
    prewarm_piper()

    report_disk()
    print_next_steps(ollama_up)
    return 0


if __name__ == "__main__":
    sys.exit(main())
