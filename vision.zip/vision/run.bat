@echo off
setlocal
cd /d "%~dp0"

where python >nul 2>&1
if errorlevel 1 (
    echo [X] Python not found. Run setup.bat first.
    pause
    exit /b 1
)

if not exist ".env" (
    echo [!] .env not found. Running setup first...
    call setup.bat
)

python ui\app.py
set ERR=%errorlevel%
if not "%ERR%"=="0" (
    echo.
    echo Vision exited with code %ERR%.
    pause
)
