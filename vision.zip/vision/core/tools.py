"""Tool implementations for Vision.

Phase 1 — open + create only. No delete, no read, no overwrite. Adnan
explicitly asked to defer those until later.

Every handler returns a dict with:
  ok:       bool
  message:  short user-facing string (what happened)
  error:    error string (only if ok=False)
  details:  any extra data (path, url, etc.)

The tool SCHEMAS list is what gets sent to qwen via Ollama's tool calling
API. Schemas describe what each tool does, when to call it, and the args.
"""

from __future__ import annotations

import os
import re
import subprocess
import urllib.parse
import webbrowser
from pathlib import Path
from typing import Any, Optional


# ── App registry ───────────────────────────────────────────────────
# Map common spoken/written names to a Windows command alias. Using `start`
# in shell mode lets Windows resolve via App Paths registry, which catches
# most installed apps. Items here are aliases — the LLM names the app, we
# look up the right launch token.

APP_MAP: dict[str, str] = {
    # browsers
    "chrome":         "chrome",
    "google chrome":  "chrome",
    "edge":           "msedge",
    "microsoft edge": "msedge",
    "firefox":        "firefox",
    "brave":          "brave",
    "opera":          "opera",

    # productivity
    "notepad":        "notepad",
    "wordpad":        "wordpad",
    "calc":           "calc",
    "calculator":     "calc",
    "paint":          "mspaint",
    "snipping":       "snippingtool",
    "snipping tool":  "snippingtool",
    "explorer":       "explorer",
    "file explorer":  "explorer",
    "files":          "explorer",
    "this pc":        "explorer",

    # shells
    "cmd":            "cmd",
    "command prompt": "cmd",
    "powershell":     "powershell",
    "terminal":       "wt",
    "windows terminal":"wt",

    # office
    "excel":          "excel",
    "word":           "winword",
    "ms word":        "winword",
    "powerpoint":     "powerpnt",
    "outlook":        "outlook",
    "onenote":        "onenote",
    "teams":          "ms-teams:",

    # code/dev
    "vscode":         "code",
    "vs code":        "code",
    "visual studio code": "code",
    "code":           "code",

    # media
    "spotify":        "spotify",
    "vlc":            "vlc",
    "media player":   "wmplayer",

    # comms / messaging
    "whatsapp":       "whatsapp:",
    "skype":          "skype:",
    "discord":        "discord",
    "slack":          "slack",
    "zoom":           "zoom",

    # system
    "settings":       "ms-settings:",
    "control panel":  "control",
    "task manager":   "taskmgr",
    "registry":       "regedit",
    "system info":    "msinfo32",
}

BROWSER_ALIASES: dict[str, str] = {
    "chrome": "chrome",
    "google chrome": "chrome",
    "edge": "msedge",
    "microsoft edge": "msedge",
    "firefox": "firefox",
    "brave": "brave",
    "opera": "opera",
}


# ── helpers ────────────────────────────────────────────────────────
def _resolve_app(name: str) -> str:
    key = name.strip().lower()
    return APP_MAP.get(key, key)


def _start_command(token: str, args: Optional[list[str]] = None) -> str:
    """Build a Windows shell command to launch a token (app alias or URI).

    Uses `start "" <token> [args...]` so the launcher returns immediately
    and Windows resolves the alias via App Paths.
    """
    parts = [f'"{a}"' if " " in a else a for a in (args or [])]
    args_str = (" " + " ".join(parts)) if parts else ""
    # quoted "" is the optional title for `start`; needed to avoid
    # `start "C:\...\with spaces"` being mistaken for a title
    return f'start "" {token}{args_str}'


# ── handlers ───────────────────────────────────────────────────────

def open_app(name: str, args: Optional[list[str]] = None) -> dict[str, Any]:
    """Launch a specific Windows application by name."""
    if not name or not name.strip():
        return {"ok": False, "error": "no app name given"}
    token = _resolve_app(name)
    cmd = _start_command(token, args)
    try:
        subprocess.Popen(cmd, shell=True)
        return {
            "ok": True,
            "message": f"Launched {name}",
            "details": {"command": cmd},
        }
    except Exception as e:
        return {"ok": False, "error": f"could not launch {name}: {e}"}


def open_url(url: str, browser: str = "default") -> dict[str, Any]:
    """Open a URL in a specific browser (or the system default)."""
    if not url or not url.strip():
        return {"ok": False, "error": "no url given"}
    url = url.strip()
    # auto-prepend https:// if scheme missing and looks like a domain
    if not re.match(r"^[a-z]+://", url, re.IGNORECASE):
        if "." in url:
            url = "https://" + url
        else:
            return {"ok": False, "error": "url needs http:// or https://"}
    # only allow http/https/whatsapp/mailto schemes
    scheme = url.split("://", 1)[0].lower()
    if scheme not in ("http", "https", "whatsapp", "mailto"):
        return {"ok": False, "error": f"scheme '{scheme}' not allowed"}

    bkey = (browser or "default").strip().lower()
    if bkey in ("default", "", "auto"):
        try:
            webbrowser.open(url)
            return {"ok": True, "message": f"Opened {url}", "details": {"url": url}}
        except Exception as e:
            return {"ok": False, "error": str(e)}

    btoken = BROWSER_ALIASES.get(bkey, bkey)
    cmd = _start_command(btoken, [url])
    try:
        subprocess.Popen(cmd, shell=True)
        return {
            "ok": True,
            "message": f"Opened {url} in {bkey}",
            "details": {"url": url, "browser": bkey},
        }
    except Exception as e:
        return {"ok": False, "error": str(e)}


def web_search(query: str, browser: str = "default", engine: str = "google") -> dict[str, Any]:
    """Run a web search in a specific browser."""
    if not query or not query.strip():
        return {"ok": False, "error": "no query given"}
    q = urllib.parse.quote_plus(query.strip())
    engines = {
        "google": f"https://www.google.com/search?q={q}",
        "bing":   f"https://www.bing.com/search?q={q}",
        "duckduckgo": f"https://duckduckgo.com/?q={q}",
        "youtube": f"https://www.youtube.com/results?search_query={q}",
    }
    url = engines.get((engine or "google").lower(), engines["google"])
    res = open_url(url, browser)
    if res.get("ok"):
        res["message"] = f"Searched '{query}' on {engine}" + (
            f" in {browser}" if browser not in (None, "", "default", "auto") else ""
        )
        res["details"] = {"query": query, "engine": engine, "browser": browser, "url": url}
    return res


def create_folder(path: str) -> dict[str, Any]:
    """Create a folder (and any missing parents). No-op if it exists."""
    if not path or not path.strip():
        return {"ok": False, "error": "no path given"}
    try:
        p = Path(path).expanduser()
        already = p.exists()
        p.mkdir(parents=True, exist_ok=True)
        return {
            "ok": True,
            "message": (
                f"Folder already existed at {p}" if already
                else f"Created folder {p}"
            ),
            "details": {"path": str(p.resolve()), "already_existed": already},
        }
    except Exception as e:
        return {"ok": False, "error": str(e)}


def create_file(path: str, content: str = "") -> dict[str, Any]:
    """Create a NEW text file. Refuses to overwrite — Adnan asked no overwrite/delete in phase 1."""
    if not path or not path.strip():
        return {"ok": False, "error": "no path given"}
    if content is None:
        content = ""
    if len(content) > 1_000_000:
        return {"ok": False, "error": "content too large (>1 MB)"}
    try:
        p = Path(path).expanduser()
        if p.exists():
            return {
                "ok": False,
                "error": f"file already exists at {p} — refusing to overwrite",
                "details": {"path": str(p.resolve())},
            }
        p.parent.mkdir(parents=True, exist_ok=True)
        p.write_text(content, encoding="utf-8")
        return {
            "ok": True,
            "message": f"Created file {p}",
            "details": {"path": str(p.resolve()), "bytes": len(content.encode("utf-8"))},
        }
    except Exception as e:
        return {"ok": False, "error": str(e)}


def open_in_app(file_path: str, app: str) -> dict[str, Any]:
    """Open a specific file with a specific app (e.g. 'report.docx' in Word)."""
    if not file_path or not file_path.strip():
        return {"ok": False, "error": "no file path"}
    if not app or not app.strip():
        return {"ok": False, "error": "no app name"}
    fp = Path(file_path).expanduser()
    if not fp.exists():
        return {"ok": False, "error": f"file not found: {fp}"}
    return open_app(app, args=[str(fp.resolve())])


# ── dispatcher ─────────────────────────────────────────────────────

HANDLERS = {
    "open_app":     open_app,
    "open_url":     open_url,
    "web_search":   web_search,
    "create_folder": create_folder,
    "create_file":  create_file,
    "open_in_app":  open_in_app,
}


def execute(name: str, args: Optional[dict] = None) -> dict[str, Any]:
    """Dispatch a tool call. Returns a result dict."""
    handler = HANDLERS.get(name)
    if handler is None:
        return {"ok": False, "error": f"unknown tool: {name}"}
    args = args or {}
    try:
        return handler(**args)
    except TypeError as e:
        return {"ok": False, "error": f"bad args for {name}: {e}"}
    except Exception as e:
        return {"ok": False, "error": f"{name} failed: {e}"}


# ── schemas (sent to Ollama / qwen as tool definitions) ────────────

SCHEMAS = [
    {
        "type": "function",
        "function": {
            "name": "open_app",
            "description": (
                "Launch a specific Windows application by name. Use this when the user "
                "says 'open <app>', 'launch <app>', 'start <app>'. Always pass the "
                "specific app the user named — never substitute. Examples of valid "
                "names: chrome, edge, firefox, notepad, calculator, paint, explorer, "
                "excel, word, vscode, spotify, settings, cmd, powershell, terminal, "
                "task manager, control panel, whatsapp."
            ),
            "parameters": {
                "type": "object",
                "properties": {
                    "name": {
                        "type": "string",
                        "description": "The exact app name the user mentioned",
                    },
                    "args": {
                        "type": "array",
                        "items": {"type": "string"},
                        "description": "Optional command-line arguments",
                    },
                },
                "required": ["name"],
            },
        },
    },
    {
        "type": "function",
        "function": {
            "name": "open_url",
            "description": (
                "Open a URL/website. If the user names a specific browser ('open this in "
                "chrome', 'in edge'), pass that browser. If they don't name one, pass "
                "'default'. Only http and https URLs are allowed."
            ),
            "parameters": {
                "type": "object",
                "properties": {
                    "url": {
                        "type": "string",
                        "description": "Full URL including https://",
                    },
                    "browser": {
                        "type": "string",
                        "enum": ["default", "chrome", "edge", "firefox", "brave", "opera"],
                        "description": "Specific browser to use; 'default' if unspecified",
                    },
                },
                "required": ["url"],
            },
        },
    },
    {
        "type": "function",
        "function": {
            "name": "web_search",
            "description": (
                "Run a web search in a browser. Use when user says 'search for X', "
                "'google X', 'find X on the web'. If the user names a specific browser, "
                "pass it. If they say 'search on YouTube' use engine=youtube."
            ),
            "parameters": {
                "type": "object",
                "properties": {
                    "query": {"type": "string", "description": "Search query"},
                    "browser": {
                        "type": "string",
                        "enum": ["default", "chrome", "edge", "firefox", "brave", "opera"],
                        "description": "Specific browser",
                    },
                    "engine": {
                        "type": "string",
                        "enum": ["google", "bing", "duckduckgo", "youtube"],
                        "description": "Search engine, default is google",
                    },
                },
                "required": ["query"],
            },
        },
    },
    {
        "type": "function",
        "function": {
            "name": "create_folder",
            "description": (
                "Create a new folder at the given path. Parent folders are created if "
                "missing. If the path is relative or just a name, place it in the user's "
                "Desktop unless they specified otherwise."
            ),
            "parameters": {
                "type": "object",
                "properties": {
                    "path": {
                        "type": "string",
                        "description": (
                            "Full path of the folder to create, e.g. "
                            "C:\\\\Users\\\\Adnan\\\\Desktop\\\\NewFolder"
                        ),
                    },
                },
                "required": ["path"],
            },
        },
    },
    {
        "type": "function",
        "function": {
            "name": "create_file",
            "description": (
                "Create a NEW text file at the given path with optional content. "
                "Refuses if the file already exists (no overwrite). For relative names, "
                "place on Desktop unless user specified otherwise."
            ),
            "parameters": {
                "type": "object",
                "properties": {
                    "path": {"type": "string", "description": "Full path including filename"},
                    "content": {"type": "string", "description": "File content (text)"},
                },
                "required": ["path"],
            },
        },
    },
    {
        "type": "function",
        "function": {
            "name": "open_in_app",
            "description": (
                "Open a specific file with a specific app. Use when the user wants a "
                "named file opened in a particular program (e.g. 'open report.docx in word')."
            ),
            "parameters": {
                "type": "object",
                "properties": {
                    "file_path": {"type": "string", "description": "Path to the file"},
                    "app":       {"type": "string", "description": "App name to open it with"},
                },
                "required": ["file_path", "app"],
            },
        },
    },
]
