"""Piper TTS — fully local neural text-to-speech.

Produces WAV bytes from text via Piper's onnxruntime models. Voice files are
downloaded from HuggingFace on first use and cached locally; after that,
synthesis is fully offline.

Per-mood voice variation is handled by `length_scale` (speed) and
`noise_scale` (expressiveness). Piper doesn't support pitch directly, but
swapping voices per mood is supported — start with a single warm voice and
add more later.

Phoneme alignments (start/end time per phoneme) are returned for accurate
lip-sync on the front-end.
"""

from __future__ import annotations

import base64
import io
import os
import re
import wave
from pathlib import Path
from typing import Optional

try:
    from piper import PiperVoice, SynthesisConfig  # type: ignore
except ImportError:
    PiperVoice = None  # type: ignore
    SynthesisConfig = None  # type: ignore

try:
    from huggingface_hub import hf_hub_download  # type: ignore
except ImportError:
    hf_hub_download = None  # type: ignore


# Default voice. Swap via VISION_VOICE env var (e.g. "en_US-lessac-medium").
DEFAULT_VOICE = os.environ.get("VISION_VOICE", "en_US-amy-medium")
HF_REPO = "rhasspy/piper-voices"

# voice key  ->  (lang dir, region, speaker, quality)
VOICE_PATHS = {
    "en_US-amy-medium":          ("en", "en_US", "amy",     "medium"),
    "en_US-lessac-medium":       ("en", "en_US", "lessac",  "medium"),
    "en_US-libritts_r-medium":   ("en", "en_US", "libritts_r", "medium"),
    "en_US-ryan-medium":         ("en", "en_US", "ryan",    "medium"),
    "en_US-ryan-high":           ("en", "en_US", "ryan",    "high"),
    "en_US-lessac-high":         ("en", "en_US", "lessac",  "high"),
    "en_GB-jenny_dioco-medium":  ("en", "en_GB", "jenny_dioco", "medium"),
    "en_GB-aru-medium":          ("en", "en_GB", "aru",     "medium"),
}

# mood -> (length_scale, noise_scale, noise_w_scale, volume)
# length_scale > 1 = slower; noise_scale = pitch variability (lively vs flat);
# noise_w_scale = timing variability (rhythmic vs metronomic). Cranked up
# from defaults so the voice doesn't sound monotone.
MOOD_SYN = {
    "friendly":     {"length_scale": 0.96, "noise_scale": 0.95, "noise_w_scale": 1.05, "volume": 1.0},
    "professional": {"length_scale": 0.94, "noise_scale": 0.6,  "noise_w_scale": 0.75, "volume": 1.0},
    "sassy":        {"length_scale": 0.85, "noise_scale": 1.10, "noise_w_scale": 1.20, "volume": 1.0},
    "calm":         {"length_scale": 1.18, "noise_scale": 0.55, "noise_w_scale": 0.65, "volume": 1.0},
    "playful":      {"length_scale": 0.83, "noise_scale": 1.20, "noise_w_scale": 1.30, "volume": 1.0},
}


def _voice_files(voice_key: str) -> tuple[str, str]:
    """Resolve the HF paths for a voice's .onnx and .onnx.json."""
    if voice_key not in VOICE_PATHS:
        raise ValueError(f"Unknown voice '{voice_key}'. Available: {list(VOICE_PATHS)}")
    lang, region, speaker, quality = VOICE_PATHS[voice_key]
    base = f"{lang}/{region}/{speaker}/{quality}/{voice_key}"
    return f"{base}.onnx", f"{base}.onnx.json"


class PiperTTS:
    def __init__(self) -> None:
        self.voice_key = DEFAULT_VOICE
        self.voice: Optional["PiperVoice"] = None
        self.last_error: Optional[str] = None

    @property
    def available(self) -> bool:
        return PiperVoice is not None and hf_hub_download is not None

    def status(self) -> dict:
        return {
            "available": self.available,
            "loaded":    self.voice is not None,
            "voice":     self.voice_key,
            "error":     self.last_error,
        }

    def _download_voice(self, voice_key: str) -> tuple[str, str]:
        """Fetch the .onnx + .onnx.json from HF (cached after first time)."""
        onnx_rel, conf_rel = _voice_files(voice_key)
        onnx_path = hf_hub_download(repo_id=HF_REPO, filename=onnx_rel)  # type: ignore
        conf_path = hf_hub_download(repo_id=HF_REPO, filename=conf_rel)  # type: ignore
        return onnx_path, conf_path

    def _ensure_loaded(self) -> bool:
        if self.voice is not None:
            return True
        if not self.available:
            self.last_error = "piper-tts or huggingface_hub not installed"
            return False
        try:
            print(f"[piper] loading voice {self.voice_key}...")
            onnx_path, _ = self._download_voice(self.voice_key)
            self.voice = PiperVoice.load(onnx_path)  # type: ignore
            print(f"[piper] voice loaded")
            return True
        except Exception as e:
            self.last_error = f"failed to load voice: {e}"
            print(f"[piper] {self.last_error}")
            return False

    # ── per-sentence content-aware synthesis ──────────────────────
    # Splitting the reply into sentences and synthesizing each with its own
    # noise_scale / length_scale gives the voice prosody that tracks the
    # message instead of one flat tone. Question marks lift the energy,
    # exclamations punch faster, emotional words add expressiveness.

    _SENT_SPLIT = re.compile(r"([.!?]+)")
    _EXCITED = re.compile(
        r"\b(wow+|oh+|amazing|love|great|awesome|yay+|wahh+|bohot+|behtareen|"
        r"ufff+|haha+|incredible|brilliant|perfect|excellent)\b",
        re.IGNORECASE,
    )
    _SAD = re.compile(
        r"\b(sorry|sad|tired|tauba|afsos|sigh|unfortunately|regret|sigh|alas)\b",
        re.IGNORECASE,
    )
    _SOFT = re.compile(r"\b(slowly|araam|chup|halka|gentle|softly)\b", re.IGNORECASE)

    def _split_sentences(self, text: str) -> list[str]:
        parts = self._SENT_SPLIT.split(text)
        sentences: list[str] = []
        cur = ""
        for p in parts:
            cur += p
            if self._SENT_SPLIT.fullmatch(p):
                s = cur.strip()
                if s:
                    sentences.append(s)
                cur = ""
        if cur.strip():
            sentences.append(cur.strip())
        return sentences or [text]

    def _content_aware_config(self, sentence: str, base: dict) -> dict:
        cfg = dict(base)
        s = sentence.strip()

        # punctuation-driven prosody
        if s.endswith("?"):
            cfg["noise_scale"]   = min(1.4, cfg["noise_scale"]   * 1.12)
            cfg["noise_w_scale"] = min(1.5, cfg["noise_w_scale"] * 1.12)
            cfg["length_scale"]  = max(0.75, cfg["length_scale"] * 0.95)
        elif s.endswith("!"):
            cfg["noise_scale"]   = min(1.45, cfg["noise_scale"]   * 1.22)
            cfg["noise_w_scale"] = min(1.55, cfg["noise_w_scale"] * 1.18)
            cfg["length_scale"]  = max(0.7,  cfg["length_scale"] * 0.88)

        # content-driven affect
        lower = s.lower()
        if self._EXCITED.search(lower):
            cfg["noise_scale"]   = min(1.45, cfg["noise_scale"] * 1.18)
            cfg["noise_w_scale"] = min(1.5,  cfg["noise_w_scale"] * 1.10)
            cfg["length_scale"]  = max(0.75, cfg["length_scale"] * 0.92)
        if self._SAD.search(lower):
            cfg["noise_scale"]   = max(0.4,  cfg["noise_scale"] * 0.80)
            cfg["length_scale"]  = min(1.35, cfg["length_scale"] * 1.12)
        if self._SOFT.search(lower):
            cfg["volume"]        = max(0.7, cfg["volume"] * 0.85)
            cfg["length_scale"]  = min(1.3, cfg["length_scale"] * 1.08)

        return cfg

    def synthesize(self, text: str, mood: str = "friendly") -> dict:
        """Synthesize text → WAV bytes (base64).

        Splits into sentences and synthesizes each with content-aware prosody
        so the tone tracks the message (questions sound questioning,
        exclamations punchy, sad words softer). Concatenates the resulting
        PCM into a single WAV, with alignment timestamps shifted to global
        timeline.
        """
        if not text or not text.strip():
            return {"ok": False, "reason": "empty"}

        if not self._ensure_loaded():
            return {"ok": False, "reason": "load_failed", "error": self.last_error}

        base_cfg = MOOD_SYN.get(mood, MOOD_SYN["friendly"])
        sentences = self._split_sentences(text)

        pcm_chunks: list[bytes] = []
        ali_list: list[dict] = []
        sample_rate = 22050           # Piper default; overwritten from first WAV
        sample_width = 2
        cum_seconds = 0.0

        for sentence in sentences:
            cfg = self._content_aware_config(sentence, base_cfg)
            try:
                syn_config = SynthesisConfig(  # type: ignore
                    length_scale=cfg["length_scale"],
                    noise_scale=cfg["noise_scale"],
                    noise_w_scale=cfg["noise_w_scale"],
                    volume=cfg["volume"],
                )
                buf = io.BytesIO()
                with wave.open(buf, "wb") as wf:
                    seg_alignments = self.voice.synthesize_wav(  # type: ignore
                        sentence,
                        wf,
                        syn_config=syn_config,
                        include_alignments=True,
                    )
                wav_bytes = buf.getvalue()
            except Exception as e:
                print(f"[piper] segment failed ({sentence[:40]}...): {e}")
                continue

            # extract raw PCM frames + sample rate from this WAV
            try:
                with wave.open(io.BytesIO(wav_bytes), "rb") as r:
                    sample_rate = r.getframerate()
                    sample_width = r.getsampwidth()
                    pcm = r.readframes(r.getnframes())
            except Exception as e:
                print(f"[piper] could not parse segment WAV: {e}")
                continue
            pcm_chunks.append(pcm)

            for a in (seg_alignments or []):
                phoneme = getattr(a, "phoneme", "") or ""
                num_samples = getattr(a, "num_samples", 0) or 0
                duration = num_samples / sample_rate if sample_rate else 0.0
                ali_list.append({
                    "p":  phoneme,
                    "t0": round(cum_seconds, 4),
                    "t1": round(cum_seconds + duration, 4),
                })
                cum_seconds += duration

        if not pcm_chunks:
            return {"ok": False, "reason": "synth_failed", "error": "no segments produced"}

        # combine PCM into a single WAV
        combined_pcm = b"".join(pcm_chunks)
        out = io.BytesIO()
        with wave.open(out, "wb") as wf:
            wf.setnchannels(1)
            wf.setsampwidth(sample_width)
            wf.setframerate(sample_rate)
            wf.writeframes(combined_pcm)
        final_wav = out.getvalue()

        return {
            "ok": True,
            "audio_b64": base64.b64encode(final_wav).decode("ascii"),
            "alignments": ali_list,
            "duration": round(len(combined_pcm) / (sample_rate * sample_width), 3),
            "voice": self.voice_key,
        }
