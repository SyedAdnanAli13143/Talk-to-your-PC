"""Ollama-backed LLM client for Vision.

Runs the model locally — no API key, no internet for inference. Wraps the
official `ollama` Python client and adds:
  * health check (is Ollama running, is the model pulled)
  * structured error returns so the front-end can surface clear setup hints
  * Roman-Urdu friendly messages (since Adnan is the audience)
"""

from __future__ import annotations

import os
from typing import Any, Optional

try:
    import ollama
    from ollama import Client as OllamaClient, ResponseError
except ImportError:  # ollama package not installed
    ollama = None
    OllamaClient = None
    ResponseError = Exception


DEFAULT_MODEL = os.environ.get("OLLAMA_MODEL", "qwen2.5:7b")
DEFAULT_HOST = os.environ.get("OLLAMA_HOST", "http://localhost:11434")
DEFAULT_NUM_PREDICT = int(os.environ.get("OLLAMA_NUM_PREDICT", "600"))


def _model_base_name(model: str) -> str:
    """`qwen2.5:7b` → `qwen2.5`. Used for fuzzy matching against `ollama list`."""
    return model.split(":", 1)[0]


class LLMClient:
    def __init__(self) -> None:
        self.host = DEFAULT_HOST
        self.model = DEFAULT_MODEL
        self.num_predict = DEFAULT_NUM_PREDICT
        self.client: Any = None
        if OllamaClient is not None:
            try:
                self.client = OllamaClient(host=self.host)
            except Exception as e:  # malformed host etc.
                print(f"[LLM] init failed: {e}")

    # ── status / health ────────────────────────────────────────────
    def status(self) -> dict:
        """Return a snapshot of whether Ollama is reachable and the model is pulled."""
        if self.client is None:
            return {
                "ok": False,
                "ollama_running": False,
                "model_pulled": False,
                "model": self.model,
                "host": self.host,
                "available": [],
                "hint": "ollama package import failed — pip install ollama",
            }
        try:
            listing = self.client.list()
            # ollama>=0.4 returns ListResponse with .models, each having .model
            raw_models = getattr(listing, "models", listing.get("models", []) if isinstance(listing, dict) else [])
            available = []
            for m in raw_models:
                name = getattr(m, "model", None) or (m.get("model") if isinstance(m, dict) else None)
                if name:
                    available.append(name)
            base = _model_base_name(self.model)
            model_pulled = any(_model_base_name(n) == base for n in available)
            return {
                "ok": model_pulled,
                "ollama_running": True,
                "model_pulled": model_pulled,
                "model": self.model,
                "host": self.host,
                "available": available,
                "hint": (
                    None
                    if model_pulled
                    else f"Model '{self.model}' nahi mila. Run karo: ollama pull {self.model}"
                ),
            }
        except Exception as e:
            return {
                "ok": False,
                "ollama_running": False,
                "model_pulled": False,
                "model": self.model,
                "host": self.host,
                "available": [],
                "hint": (
                    "Ollama service chal nahi raha. Install karo: https://ollama.com/download "
                    "— ya 'ollama serve' run karo. "
                    f"(error: {type(e).__name__})"
                ),
            }

    @property
    def ready(self) -> bool:
        return self.status().get("ok", False)

    # ── chat completion ────────────────────────────────────────────
    def reply(
        self,
        system_prompt: str,
        history: list[dict],
        user_text: str,
        tools: Optional[list[dict]] = None,
        tool_executor=None,
        max_tool_iterations: int = 4,
    ) -> dict:
        """Run one chat turn.

        If `tools` is provided, the model can call them. `tool_executor` is a
        callable `(name: str, args: dict) -> dict`. We loop until the model
        either produces a final text reply or hits `max_tool_iterations`.

        Returns:
          {ok, text, actions, [reason], [error]}
          where `actions` is a list of {tool, args, result} entries.
        """
        if self.client is None:
            return {
                "ok": False,
                "reason": "no_client",
                "text": "Ollama client ready nahi hai. Pehle 'pip install ollama' karo.",
                "actions": [],
            }

        messages: list[dict] = [{"role": "system", "content": system_prompt}]
        messages.extend(history)
        messages.append({"role": "user", "content": user_text})

        actions: list[dict] = []

        for iteration in range(max_tool_iterations + 1):
            try:
                kwargs = {
                    "model": self.model,
                    "messages": messages,
                    "stream": False,
                    "options": {
                        "num_predict": self.num_predict,
                        "temperature": 0.75,
                        "top_p": 0.9,
                    },
                }
                if tools:
                    kwargs["tools"] = tools
                resp = self.client.chat(**kwargs)
            except ResponseError as e:
                m = str(e).lower()
                if "model" in m and ("not found" in m or "not exist" in m or "pull" in m):
                    return {
                        "ok": False,
                        "reason": "model_not_pulled",
                        "text": f"Model '{self.model}' download nahi hua. Run karo: ollama pull {self.model}",
                        "actions": actions,
                    }
                return {"ok": False, "reason": "ollama_error", "text": f"Ollama error: {e}", "actions": actions}
            except ConnectionError:
                return {
                    "ok": False,
                    "reason": "ollama_offline",
                    "text": "Ollama service connect nahi ho raha. 'ollama serve' run karo.",
                    "actions": actions,
                }
            except Exception as e:
                name = type(e).__name__
                if "Connect" in name or "Timeout" in name:
                    return {
                        "ok": False,
                        "reason": "ollama_offline",
                        "text": "Ollama tak nahi pohanch saka. Service chal rahi hai?",
                        "actions": actions,
                    }
                return {"ok": False, "reason": "unknown", "text": f"Kuch ghalat ho gaya: {e}", "actions": actions}

            # extract message
            msg_obj = getattr(resp, "message", None)
            if msg_obj is None and isinstance(resp, dict):
                msg_obj = resp.get("message")

            content = ""
            tool_calls = []
            if msg_obj is not None:
                content = getattr(msg_obj, "content", None)
                if content is None and isinstance(msg_obj, dict):
                    content = msg_obj.get("content", "")
                content = (content or "").strip()
                tool_calls = getattr(msg_obj, "tool_calls", None) or []
                if not tool_calls and isinstance(msg_obj, dict):
                    tool_calls = msg_obj.get("tool_calls") or []

            # No tool calls → final reply
            if not tool_calls or tool_executor is None or not tools:
                return {"ok": True, "text": content, "actions": actions}

            # Append assistant's tool-call message back into history so the
            # subsequent tool-results have something to reference
            asst_msg = {"role": "assistant", "content": content}
            asst_msg["tool_calls"] = [
                _serialize_tool_call(tc) for tc in tool_calls
            ]
            messages.append(asst_msg)

            # Execute each tool and append the result
            for tc in tool_calls:
                fn = getattr(tc, "function", None) or (tc.get("function") if isinstance(tc, dict) else None)
                tool_name = ""
                tool_args: dict = {}
                if fn is not None:
                    tool_name = getattr(fn, "name", None) or (fn.get("name") if isinstance(fn, dict) else "") or ""
                    raw_args = getattr(fn, "arguments", None)
                    if raw_args is None and isinstance(fn, dict):
                        raw_args = fn.get("arguments")
                    if isinstance(raw_args, str):
                        try:
                            import json as _json
                            tool_args = _json.loads(raw_args)
                        except Exception:
                            tool_args = {}
                    elif isinstance(raw_args, dict):
                        tool_args = raw_args
                    else:
                        tool_args = {}

                result = tool_executor(tool_name, tool_args)
                actions.append({"tool": tool_name, "args": tool_args, "result": result})

                import json as _json
                messages.append({
                    "role": "tool",
                    "name": tool_name,
                    "content": _json.dumps(result),
                })

            # Loop continues — model now sees the results and produces a final reply

        # iteration cap reached
        return {
            "ok": True,
            "text": (content or "Done."),
            "actions": actions,
            "truncated": True,
        }


def _serialize_tool_call(tc) -> dict:
    """Coerce ollama's tool_call object back to a JSON-able dict."""
    fn = getattr(tc, "function", None) or (tc.get("function") if isinstance(tc, dict) else {})
    name = getattr(fn, "name", None) or (fn.get("name") if isinstance(fn, dict) else "") or ""
    args = getattr(fn, "arguments", None)
    if args is None and isinstance(fn, dict):
        args = fn.get("arguments", {})
    return {"function": {"name": name, "arguments": args or {}}}
