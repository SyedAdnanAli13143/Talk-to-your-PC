"""Local Whisper STT — offline speech-to-text via faster-whisper.

Replaces the browser's Web Speech API (which is unreliable in WebView2).
Audio is captured in the browser as webm/opus, base64-encoded, sent through
the pywebview bridge, decoded here, and fed to faster-whisper.

The model loads lazily on the first transcribe() call so app startup stays
fast. Subsequent calls reuse the loaded model.
"""

from __future__ import annotations

import base64
import os
import tempfile
from typing import Optional

try:
    from faster_whisper import WhisperModel  # type: ignore
except ImportError:  # not installed
    WhisperModel = None  # type: ignore


DEFAULT_SIZE = os.environ.get("WHISPER_MODEL", "small")        # tiny | base | small | medium | large-v3
DEFAULT_DEVICE = os.environ.get("WHISPER_DEVICE", "auto")      # auto | cuda | cpu
DEFAULT_COMPUTE = os.environ.get("WHISPER_COMPUTE", "auto")    # auto | int8 | int8_float16 | float16 | float32


class WhisperSTT:
    def __init__(self) -> None:
        self.size = DEFAULT_SIZE
        self.requested_device = DEFAULT_DEVICE
        self.requested_compute = DEFAULT_COMPUTE
        self.model = None
        self.actual_device: Optional[str] = None
        self.last_error: Optional[str] = None

    @property
    def available(self) -> bool:
        return WhisperModel is not None

    def _ensure_loaded(self) -> bool:
        if self.model is not None:
            return True
        if not self.available:
            self.last_error = "faster-whisper not installed"
            return False

        # try CUDA first if requested or auto, fall back to CPU
        attempts: list[tuple[str, str]] = []
        if self.requested_device in ("auto", "cuda"):
            attempts.append(("cuda", "int8" if self.requested_compute == "auto" else self.requested_compute))
        if self.requested_device in ("auto", "cpu"):
            attempts.append(("cpu", "int8" if self.requested_compute == "auto" else self.requested_compute))

        last_err = None
        for device, compute_type in attempts:
            try:
                print(f"[whisper] loading {self.size} on {device} ({compute_type})...")
                self.model = WhisperModel(self.size, device=device, compute_type=compute_type)
                self.actual_device = device
                print(f"[whisper] loaded on {device}")
                return True
            except Exception as e:
                last_err = e
                print(f"[whisper] failed on {device}: {e}")
                continue

        self.last_error = f"could not load whisper: {last_err}"
        return False

    def status(self) -> dict:
        return {
            "available": self.available,
            "loaded": self.model is not None,
            "model": self.size,
            "device": self.actual_device,
            "error": self.last_error,
        }

    def transcribe(self, audio_b64: str, lang: Optional[str] = None) -> dict:
        """Decode the base64 audio blob and return transcription."""
        if not audio_b64:
            return {"ok": False, "reason": "empty", "text": ""}

        if not self._ensure_loaded():
            return {
                "ok": False,
                "reason": "load_failed",
                "text": "",
                "error": self.last_error,
            }

        try:
            audio_bytes = base64.b64decode(audio_b64)
        except Exception as e:
            return {"ok": False, "reason": "decode_failed", "text": "", "error": str(e)}

        # write to a temp file — av (bundled with faster-whisper) decodes webm/opus from path
        suffix = ".webm"
        try:
            with tempfile.NamedTemporaryFile(suffix=suffix, delete=False) as f:
                f.write(audio_bytes)
                tmp_path = f.name
        except Exception as e:
            return {"ok": False, "reason": "write_failed", "text": "", "error": str(e)}

        # normalize lang code: "ur-PK" → "ur", "en-US" → "en", "" → None (auto-detect)
        lang_code = None
        if lang:
            lang_code = lang.split("-")[0].lower()
            if lang_code not in {"en", "ur", "hi", "ar"}:
                lang_code = None

        def _run_transcribe():
            segments, info = self.model.transcribe(  # type: ignore[union-attr]
                tmp_path,
                language=lang_code,
                vad_filter=True,
                beam_size=1,                  # greedy = faster
                condition_on_previous_text=False,
            )
            text = " ".join(seg.text.strip() for seg in segments).strip()
            return {
                "ok": True,
                "text": text,
                "language": getattr(info, "language", None),
                "language_probability": getattr(info, "language_probability", None),
                "duration": getattr(info, "duration", None),
            }

        try:
            return _run_transcribe()
        except Exception as e:
            err_str = str(e).lower()
            cuda_problem = any(s in err_str for s in ("cublas", "cudnn", "cuda", "gpu", "cu12", "cu11"))
            if cuda_problem and self.actual_device != "cpu":
                # CUDA inference failed at runtime — reload on CPU and retry once
                print(f"[whisper] CUDA inference failed, falling back to CPU: {e}")
                try:
                    self.model = WhisperModel(self.size, device="cpu", compute_type="int8")  # type: ignore
                    self.actual_device = "cpu"
                    return _run_transcribe()
                except Exception as e2:
                    return {"ok": False, "reason": "transcribe_failed", "text": "", "error": str(e2)}
            return {"ok": False, "reason": "transcribe_failed", "text": "", "error": str(e)}
        finally:
            try:
                os.unlink(tmp_path)
            except Exception:
                pass
